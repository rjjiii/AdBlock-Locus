restart icons courtesy of jaggedben from deviantart
http://jaggedben.deviantart.com/art/restart-icons-2583627

(c)creative commons